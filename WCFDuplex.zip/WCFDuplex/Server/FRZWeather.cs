﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DuplexLib;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace Server
{
    public class FRZWeather : IWeatherUpdate
    {
       
        public void RegisterToWeatherUpdates()
        {
            Program._client = OperationContext.Current.GetCallbackChannel<IWeatherCallback>();
            //Program._clientlist.Add(OperationContext.Current.GetCallbackChannel<IWeatherCallback>());
        }
    }
}
