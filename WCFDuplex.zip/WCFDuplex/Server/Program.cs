﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using DuplexLib;


namespace Server
{
    class Program
    {
        public static IWeatherCallback _client;
        //public static List<IWeatherCallback> _clientlist;
        static void Main(string[] args)
        {
            ServiceHost _host = new ServiceHost(typeof(FRZWeather), new Uri("net.tcp://localhost:1601/weathersrv"));
            _host.Open();

            Console.WriteLine("Enter the new weather Updates and press enter...");
            String weatherupdate="";
            while (weatherupdate.ToLower() != "end")
            {
                weatherupdate = Console.ReadLine();
                _client.NewWeatherUpdate(weatherupdate);
            }


            Console.ReadLine();
        }
    }
}
