﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using DuplexLib;

namespace Client
{
    class Program 
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Press a key to start...");
            Console.ReadLine();

            MyUpdateing upd = new MyUpdateing();

            DuplexChannelFactory<IWeatherUpdate> factory = new DuplexChannelFactory<IWeatherUpdate>(upd,"*");
            IWeatherUpdate _srv = factory.CreateChannel();
            _srv.RegisterToWeatherUpdates();
            Console.ReadLine();

        }
        public void NewWeatherUpdate(string update)
        {
            Console.WriteLine(update);
        }

    }

    public class MyUpdateing : IWeatherCallback
    {
        public void NewWeatherUpdate(string update)
        {
            Console.WriteLine(update);
        }
    }
}
