﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace DuplexLib
{
    [ServiceContract(CallbackContract=typeof(IWeatherCallback))]
    public interface IWeatherUpdate
    {
        [OperationContract]
        void RegisterToWeatherUpdates();
    }

    [ServiceContract]
    public interface IWeatherCallback
    {
        [OperationContract(IsOneWay=true)]
        void NewWeatherUpdate(string update);
    }

}
